<?php
if($_POST){
    $id=$_POST['id_member'];
    $nama=$_POST['nama'];
    $alamat=$_POST['alamat'];
    $gender=$_POST['gender'];
    $tlp=$_POST['tlp'];

        if(empty($nama)||empty($alamat)||empty($gender)||empty($tlp)){
            echo "<script>alert('Semua data harus di isi!');location.href='ubah_member.php?id=$id'</script>";
            } else {
            include "koneksi.php";
            $query = "update member set nama='$nama', alamat='$alamat', gender='$gender', tlp='$tlp' where id_member='$id'";
            $update=mysqli_query($conn,$query);
            if($update){
                echo "<script>alert('Sukses update data');location.href='tampil_member.php';</script>";
            } else {
                echo "<script>alert('Gagal update pelanggan');location.href='ubah_member.php?id_member=".$id."';</script>";
            } 
        }
    }
?>