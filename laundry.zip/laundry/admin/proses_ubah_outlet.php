<?php
if($_POST){
    $id=$_POST['id'];
    $nama=$_POST['nama'];
    $alamat=$_POST['alamat'];

        if(empty($nama)||empty($alamat)){
            echo "<script>alert('Semua data harus di isi!');location.href='update_outlet.php?id=$id'</script>";
            } else {
            include "koneksi.php";
            $query = "update outlet set nama='$nama', alamat='$alamat' where id='$id'";
            $update=mysqli_query($conn,$query);
            if($update){
                echo "<script>alert('Sukses update data');location.href='tampil_outlet.php';</script>";
            } else {
                echo "<script>alert('Gagal update pelanggan');location.href='edit_outlet.php?id=".$id."';</script>";
            } 
        }
    }
?>