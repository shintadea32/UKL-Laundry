<?php
if($_POST){
    $jenis=$_POST['jenis'];
    $harga=$_POST['harga'];

    if(empty($jenis)||empty($harga)){
        echo "<script>alert('Semua data harus diisi!');location.href='tambah_paket.php';</script>";
    }else{
        include "koneksi.php";
        $input=mysqli_query($conn, "insert into paket (jenis, harga) value ('".$jenis."','".$harga."')") or die(mysqli_error($koneksi));
        if($input){
            echo "<script>alert('Sukses menambahkan paket.');location.href='tampil_paket.php';</script>";
        }else{
            echo "<script>alert('Gagal menambahkan paket.');location.href='tambah_paket.php';</script>";
        }
    }
}