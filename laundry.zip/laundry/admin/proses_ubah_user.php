<?php
if($_POST){
    $id=$_POST['id'];
    $nama=$_POST['nama'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $role=$_POST['role'];

    if(empty($nama)||empty($username)||empty($password)||empty($role)){
        echo "<script>alert('Semua data harus diisi');location.href='ubah_user.php?id=$id'</script>";
    }else{
        include "koneksi.php";
        $query = "update user set nama='$nama', username='$username', password='$password', role='$role' where id='$id'";
        $update=mysqli_query($conn, $query);
        if($update){
            echo "<script>alert('Sukses update data user');location.href='tampil_user.php';</script>";
        }else{
            echo "<script>alert('Gagal update data user');location.href='ubah_user.php';</script>";
        }
    }
}
?>