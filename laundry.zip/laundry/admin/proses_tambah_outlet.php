<?php
if($_POST){
    $nama=$_POST['nama'];
    $alamat=$_POST['alamat'];

    if(empty($nama)||empty($alamat)){
        echo "<script>alert('Semua data harus diisi');location.href='tambah_outlet.php';</script>";
    }else{
        include "koneksi.php";
        $input=mysqli_query($conn, "insert into outlet (nama, alamat) value ('".$nama."','".$alamat."')") or die(mysqli_error($conn));
        if($input){
            echo "<script>alert('Sukses menambahkan outlet.');location.href='tampil_outlet.php';</script>";
        } else{
            echo "<script>alert('Gagal menambahkan outlet.');location.href='tambah_outlet.php';</script>";
        }
    }
}
?>